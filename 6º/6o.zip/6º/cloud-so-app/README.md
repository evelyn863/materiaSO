# cloud-so-app

Aplicação Express.js que mostra informações do sistema operacional onde está rodando (nome do host, plataforma, arquitetura, CPUs, memória total e livre, tempo de atividade). Atividade 6 de Sistemas Operacionais I.

## Como executar localmente

```bash
npm install
npm start
```

Abra http://localhost:3000 no navegador. A rota `/api/info` devolve os mesmos dados em JSON.

## Publicação no Render

- Build Command: `npm install`
- Start Command: `npm start`
- A porta é lida da variável de ambiente `PORT`.

O passo a passo completo está no `Manual.md`, na pasta acima.
