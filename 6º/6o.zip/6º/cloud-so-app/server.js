// cloud-so-app
// Aplicação Express.js que exibe informações do sistema operacional
// onde ela está sendo executada (máquina local ou nuvem/Render).

const express = require('express');
const os = require('os');

const app = express();

// Em ambientes de nuvem (Render) a porta é definida pela variável de ambiente PORT.
// Localmente, usamos 3000 como padrão.
const PORT = process.env.PORT || 3000;

// Converte bytes para gigabytes com 2 casas decimais.
const toGB = (bytes) => (bytes / 1024 ** 3).toFixed(2);

// Converte segundos em um texto legível: "1d 2h 3min 4s".
function formatUptime(totalSeconds) {
  const d = Math.floor(totalSeconds / 86400);
  const h = Math.floor((totalSeconds % 86400) / 3600);
  const m = Math.floor((totalSeconds % 3600) / 60);
  const s = Math.floor(totalSeconds % 60);
  return `${d}d ${h}h ${m}min ${s}s`;
}

// Evita que texto vindo do sistema seja interpretado como HTML.
function escapeHtml(text) {
  return String(text)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

// Coleta as informações usando o módulo nativo "os" e o objeto "process" do Node.js.
function getSystemInfo() {
  const totalMem = os.totalmem();
  const freeMem = os.freemem();
  const usedMem = totalMem - freeMem;
  const cpus = os.cpus();
  const procMem = process.memoryUsage();

  return {
    // Informações pedidas na atividade
    hostname: os.hostname(),
    platform: os.platform(),
    arch: os.arch(),
    cpuCount: cpus.length,
    totalMemory: `${toGB(totalMem)} GB`,
    freeMemory: `${toGB(freeMem)} GB`,
    uptime: formatUptime(os.uptime()),

    // Informações extras, úteis para a análise de SO
    osType: os.type(),
    osRelease: os.release(),
    cpuModel: cpus.length > 0 ? cpus[0].model : 'indisponível',
    usedMemory: `${toGB(usedMem)} GB`,
    usedMemoryPercent: `${((usedMem / totalMem) * 100).toFixed(1)}%`,
    loadAverage: os.loadavg().map((n) => n.toFixed(2)).join(' / '),
    nodeVersion: process.version,
    processId: process.pid,
    processUptime: formatUptime(process.uptime()),
    processMemoryRss: `${(procMem.rss / 1024 ** 2).toFixed(1)} MB`,
    processHeapUsed: `${(procMem.heapUsed / 1024 ** 2).toFixed(1)} MB`,
    collectedAt: new Date().toISOString(),
  };
}

// Rota da página web
app.get('/', (req, res) => {
  const info = getSystemInfo();

  const row = (label, value) =>
    `<tr><th>${label}</th><td>${escapeHtml(value)}</td></tr>`;

  res.send(`<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="refresh" content="10">
  <title>cloud-so-app</title>
  <style>
    body { font-family: Arial, sans-serif; background: #f4f6f8; color: #222; margin: 0; padding: 24px; }
    main { max-width: 760px; margin: 0 auto; }
    h1 { margin-bottom: 4px; }
    p.sub { margin-top: 0; color: #555; }
    section { background: #fff; border-radius: 8px; padding: 16px 20px; margin-bottom: 20px; box-shadow: 0 1px 4px rgba(0,0,0,.1); }
    h2 { margin-top: 0; font-size: 1.1rem; border-bottom: 2px solid #e3e7eb; padding-bottom: 6px; }
    table { width: 100%; border-collapse: collapse; }
    th { text-align: left; width: 40%; padding: 6px 8px; color: #444; }
    td { padding: 6px 8px; font-family: monospace; word-break: break-all; }
    tr:nth-child(even) { background: #f9fafb; }
    footer { font-size: .85rem; color: #666; }
  </style>
</head>
<body>
  <main>
    <h1>cloud-so-app</h1>
    <p class="sub">Informações do sistema operacional onde esta aplicação está em execução.</p>

    <section>
      <h2>Sistema operacional</h2>
      <table>
        ${row('Nome do host', info.hostname)}
        ${row('Plataforma', info.platform)}
        ${row('Tipo do SO', info.osType)}
        ${row('Versão do kernel/SO', info.osRelease)}
        ${row('Arquitetura', info.arch)}
        ${row('Tempo de atividade do sistema', info.uptime)}
      </table>
    </section>

    <section>
      <h2>CPU</h2>
      <table>
        ${row('Quantidade de CPUs', String(info.cpuCount))}
        ${row('Modelo', info.cpuModel)}
        ${row('Carga média (1 / 5 / 15 min)', info.loadAverage)}
      </table>
    </section>

    <section>
      <h2>Memória do sistema</h2>
      <table>
        ${row('Memória total', info.totalMemory)}
        ${row('Memória livre', info.freeMemory)}
        ${row('Memória em uso', info.usedMemory + ' (' + info.usedMemoryPercent + ')')}
      </table>
    </section>

    <section>
      <h2>Processo Node.js</h2>
      <table>
        ${row('Versão do Node.js', info.nodeVersion)}
        ${row('PID do processo', String(info.processId))}
        ${row('Tempo de atividade do processo', info.processUptime)}
        ${row('Memória RSS do processo', info.processMemoryRss)}
        ${row('Heap usado', info.processHeapUsed)}
      </table>
    </section>

    <footer>
      Coletado em ${escapeHtml(info.collectedAt)} &middot; a página atualiza sozinha a cada 10 s &middot;
      <a href="/api/info">ver em JSON</a>
    </footer>
  </main>
</body>
</html>`);
});

// Rota JSON com os mesmos dados (útil para testes e comparações)
app.get('/api/info', (req, res) => {
  res.json(getSystemInfo());
});

app.listen(PORT, () => {
  console.log(`cloud-so-app rodando na porta ${PORT}`);
});
