# Manual da Atividade 6 — cloud-so-app

**Disciplina:** Sistemas Operacionais I
**Autora:** Evelyn Antunes (evelyn863)
**Tema:** Aplicação Express.js que exibe informações do sistema operacional, executada localmente e na nuvem (Render)

> **Como usar este manual:** as partes marcadas com **[PREENCHER]** dependem de resultados reais da sua máquina e do Render (prints, valores, URL). Preencha-as depois de executar os testes.

---

## 1. Objetivo

Desenvolver uma aplicação web com Node.js e Express.js que exiba informações do sistema operacional hospedeiro, executá-la localmente, publicá-la na nuvem (Render) e comparar os dois ambientes, relacionando o resultado com os conceitos de Sistemas Operacionais vistos em aula.

## 2. Instalação das ferramentas

| Ferramenta | Para que serve | Como instalar |
|---|---|---|
| Node.js (LTS, versão 18 ou superior) | Executa JavaScript fora do navegador | Baixar em https://nodejs.org e instalar |
| npm | Gerenciador de pacotes (vem com o Node.js) | Instalado junto com o Node.js |
| Git | Controle de versão | https://git-scm.com |
| Editor de código (VS Code) | Escrever o código | https://code.visualstudio.com |
| Conta no GitHub | Hospedar o código | https://github.com |
| Conta no Render | Publicar a aplicação na nuvem | https://render.com |

Verificação da instalação (no terminal):

```bash
node -v
npm -v
git --version
```

**[PREENCHER]** versões instaladas na sua máquina: Node ___ / npm ___ / Git ___

## 3. Criação do projeto

```bash
mkdir cloud-so-app
cd cloud-so-app
npm init -y
npm install express
```

O `npm init -y` cria o `package.json` e o `npm install express` adiciona o Express como dependência e cria a pasta `node_modules`. Foi criado também um arquivo `.gitignore` com `node_modules/`, para que as dependências não sejam enviadas ao GitHub.

Estrutura final:

```
cloud-so-app/
├── package.json
├── server.js
├── .gitignore
└── README.md
```

No `package.json` foi adicionado o script de inicialização, usado também pelo Render:

```json
"scripts": { "start": "node server.js" }
```

## 4. Desenvolvimento da aplicação

O código está em `cloud-so-app/server.js`. Principais pontos:

- **`require('os')`**: módulo nativo do Node.js que consulta o sistema operacional.
- **`os.hostname()`**: nome do host.
- **`os.platform()`** e **`os.arch()`**: plataforma (linux, win32, darwin) e arquitetura (x64, arm64).
- **`os.cpus().length`**: quantidade de CPUs lógicas.
- **`os.totalmem()`** e **`os.freemem()`**: memória total e livre, em bytes (convertidos para GB).
- **`os.uptime()`**: tempo de atividade do sistema, em segundos (formatado em dias, horas, minutos e segundos).
- **`process`**: informações do processo Node.js (PID, memória RSS, heap, tempo de atividade).
- **`process.env.PORT || 3000`**: usa a porta definida pelo ambiente (Render) ou 3000 localmente.
- **Rotas**: `/` mostra a página HTML e `/api/info` devolve os mesmos dados em JSON.

A página se atualiza sozinha a cada 10 segundos, o que permite observar a variação da memória livre e do tempo de atividade.

## 5. Testes locais

```bash
npm install
npm start
```

Saída esperada no terminal: `cloud-so-app rodando na porta 3000`. Em seguida, abrir http://localhost:3000 no navegador e também http://localhost:3000/api/info.

Checklist de testes:

- [ ] A página abre sem erros
- [ ] Todos os campos aparecem preenchidos
- [ ] A página atualiza após 10 s
- [ ] A rota `/api/info` devolve JSON válido
- [ ] Encerrar com Ctrl+C e subir de novo reinicia o tempo de atividade do processo

**[PREENCHER]** valores obtidos na máquina local (anexe um print):

| Campo | Valor local |
|---|---|
| Nome do host | |
| Plataforma | |
| Arquitetura | |
| Quantidade de CPUs | |
| Memória total | |
| Memória livre | |
| Tempo de atividade do sistema | |

## 6. Publicação no GitHub

O projeto foi salvo no repositório da disciplina (`materiaSO`), seguindo a sequência das atividades anteriores, na pasta `6º`:

```
materiaSO/
├── 1º/ ...
├── 3/ ...
├── 4º/ ...
├── 5º/ ...
└── 6º/
    ├── Manual.md
    └── cloud-so-app/
```

Comandos usados para enviar alterações pelo terminal:

```bash
git add .
git commit -m "Atividade 6: cloud-so-app"
git push
```

Link: https://github.com/evelyn863/materiaSO/tree/main/6%C2%BA

## 7. Publicação no Render

1. Acessar https://render.com e criar a conta (a opção "Sign in with GitHub" facilita a ligação com o repositório).
2. No painel, clicar em **New +** e escolher **Web Service**.
3. Conectar o GitHub e selecionar o repositório `materiaSO`.
4. Configurar:
   - **Name:** `cloud-so-app`
   - **Branch:** `main`
   - **Root Directory:** `6º/cloud-so-app`
   - **Runtime:** Node
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
   - **Instance Type:** Free
5. Clicar em **Create Web Service** e aguardar o deploy (acompanhar os logs).
6. Ao terminar, o Render mostra a URL pública, no formato `https://cloud-so-app-xxxx.onrender.com`.

> **Observação:** se o Render não aceitar o caractere `º` no campo Root Directory, uma alternativa é criar um repositório separado chamado `cloud-so-app` somente com o conteúdo da pasta, e apontar o Render para ele (Root Directory em branco).

> **Observação:** no plano gratuito, o serviço "dorme" após alguns minutos sem acessos e a primeira requisição depois disso demora para responder.

**[PREENCHER]** URL publicada: ______________________________

## 8. Comparação entre ambiente local e nuvem

Abrir a URL do Render e comparar com os valores obtidos na seção 5.

**[PREENCHER]** tabela comparativa:

| Campo | Local | Render (nuvem) |
|---|---|---|
| Nome do host | | |
| Plataforma | | |
| Arquitetura | | |
| Quantidade de CPUs | | |
| Memória total | | |
| Memória livre | | |
| Tempo de atividade do sistema | | |
| Versão do Node.js | | |

### Diferenças que normalmente são observadas

Estas são diferenças típicas; confirme com os seus números e ajuste o texto:

- **Plataforma:** o Render executa em Linux. Se a sua máquina usa Windows (`win32`) ou macOS (`darwin`), a plataforma será diferente.
- **Nome do host:** na nuvem é um identificador gerado automaticamente para o contêiner, sem relação com o nome do seu computador.
- **Recursos (CPU e memória):** no plano gratuito os limites do serviço costumam ser bem menores que os de um computador pessoal. Em ambientes com contêineres, `os.totalmem()` e `os.cpus()` podem mostrar valores do servidor físico e não do limite real imposto ao serviço.
- **Tempo de atividade:** na máquina local reflete o tempo desde o último boot do computador; na nuvem reflete o servidor/contêiner, que pode ser reiniciado a qualquer momento pela plataforma.
- **Carga média (`loadavg`):** no Windows o valor é sempre 0; no Linux (Render) mostra a carga real do host.
- **Rede e disponibilidade:** localmente só você acessa (`localhost`); na nuvem a aplicação é pública, com HTTPS e URL própria.
- **Controle:** localmente você controla o sistema inteiro; na nuvem você controla apenas a aplicação, e a plataforma controla o resto.

## 9. Conceitos de Sistemas Operacionais identificados no projeto

### 9.1 Processos

Ao executar `npm start`, o SO cria um **processo** que roda o interpretador Node.js com o `server.js`. Esse processo tem um **PID** (exibido na página por `process.pid`), espaço de endereçamento próprio e um ciclo de vida: é criado, fica em execução, aguardando requisições, e termina com Ctrl+C ou quando a plataforma o encerra. O tempo de atividade do processo (`process.uptime()`) é diferente do tempo de atividade do sistema (`os.uptime()`), e essa diferença mostra que um processo vive dentro do sistema, mas não tem a mesma duração dele.

O Node.js executa o código JavaScript em uma única thread principal com laço de eventos (*event loop*), e o SO escalona essa thread, junto com as demais threads internas do runtime e de outros processos, na CPU.

### 9.2 Gerenciamento de memória

O SO controla a **memória física** (RAM). `os.totalmem()` e `os.freemem()` consultam diretamente essas informações do kernel. Cada processo recebe memória **virtual**, e o SO faz o mapeamento para a memória física (paginação), podendo usar **swap** quando a RAM acaba. Na página aparecem a memória do sistema e também a do processo: **RSS** (*Resident Set Size*, parte da memória do processo que está de fato na RAM) e **heap usado** (memória alocada pelo motor V8 para objetos JavaScript, gerenciada por coleta de lixo). Em Linux, a memória "livre" costuma parecer baixa porque o SO usa a RAM ociosa como cache de disco; por isso `freemem` nem sempre indica pressão de memória.

### 9.3 Uso de CPU

`os.cpus()` lista os núcleos lógicos e seus modelos. O **escalonador** do SO decide qual processo ou thread usa cada CPU em cada instante. A **carga média** (`os.loadavg()`) mostra quantos processos, em média, estavam executando ou esperando CPU nos últimos 1, 5 e 15 minutos: valores próximos ou acima do número de CPUs indicam saturação. Como o Node.js usa uma thread principal, uma única instância não aproveita todos os núcleos, a menos que se use *cluster* ou *worker threads*.

### 9.4 Sistema operacional hospedeiro

O SO **hospedeiro** é aquele no qual a aplicação realmente roda. A aplicação não acessa o hardware diretamente: o módulo `os` do Node.js usa **chamadas de sistema** (*system calls*) para pedir as informações ao kernel. Essa camada permite que o mesmo código funcione em Windows, Linux e macOS, mas mostrando valores diferentes em cada um, o que é visível na comparação entre local e nuvem (`platform`, `arch`, `release`).

### 9.5 Virtualização

Na nuvem, a aplicação não roda em um computador dedicado a ela. Os servidores físicos são divididos em várias **máquinas virtuais** e/ou **contêineres**, geridos por um **hipervisor** e pelo kernel do SO hospedeiro, que isolam e limitam recursos de cada cliente. Por isso o nome do host é genérico, os recursos podem ser limitados e algumas leituras do `os` podem refletir o servidor físico em vez do limite do serviço. A virtualização de SO (contêineres) compartilha o kernel do host, usando recursos como *namespaces* e *cgroups* do Linux para isolar processos e limitar CPU e memória.

### 9.6 Computação em nuvem

O Render é um exemplo de **PaaS** (*Platform as a Service*): a plataforma cuida do servidor, do SO, da rede e do HTTPS, e o desenvolvedor entrega apenas o código. As características de computação em nuvem observadas foram: **acesso sob demanda** por URL pública; **elasticidade** e escalonamento de recursos conforme o plano contratado; **abstração da infraestrutura** (não se sabe em qual máquina física o serviço roda); **medição e limites** por plano; e **ciclo de vida gerenciado** (o serviço gratuito pode ser suspenso por inatividade e reiniciado pela plataforma).

### 9.7 Quadro-resumo

| Conceito | Onde aparece no projeto |
|---|---|
| Processo | PID, `process.uptime()`, execução via `npm start` |
| Memória | `totalmem`, `freemem`, RSS, heap |
| CPU e escalonamento | `os.cpus()`, `os.loadavg()`, thread única do Node.js |
| SO hospedeiro | `platform`, `arch`, `release`, módulo `os` (chamadas de sistema) |
| Virtualização | Diferenças de host/recursos entre local e Render |
| Computação em nuvem | Deploy no Render (PaaS), URL pública, limites do plano |

## 10. Conclusões

A atividade mostrou, na prática, que uma aplicação não é independente do ambiente: ela depende do sistema operacional hospedeiro para obter recursos como CPU, memória e rede, e o mesmo código apresenta resultados diferentes conforme onde é executado. A comparação entre a máquina local e o Render evidenciou a diferença entre ter controle total do sistema e usar uma plataforma que abstrai a infraestrutura por meio de virtualização, o que facilita o deploy, mas impõe limites de recursos e menor controle.

**[PREENCHER]** adicione aqui as suas conclusões pessoais com base nos números que você observou (por exemplo, quais diferenças mais chamaram a atenção e dificuldades encontradas durante o deploy).

## 11. Referências

- Documentação do módulo `os` do Node.js: https://nodejs.org/api/os.html
- Documentação do objeto `process` do Node.js: https://nodejs.org/api/process.html
- Documentação do Express.js: https://expressjs.com
- Documentação do Render (Node/Express): https://render.com/docs
