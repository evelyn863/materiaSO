// Código executado no navegador: busca /api/info a cada 5 segundos
// e atualiza os indicadores e as tabelas da página.

const $ = (id) => document.getElementById(id);

// Define a cor da barra conforme o percentual (verde, amarelo ou vermelho)
function setBar(id, percent) {
  const bar = $(id);
  bar.style.width = Math.min(percent, 100) + '%';
  const level = percent >= 90 ? 'critical' : percent >= 75 ? 'warning' : 'ok';
  bar.className = 'bar-fill ' + level;
}

// Preenche uma tabela com linhas [rótulo, valor]
// (textContent evita que qualquer texto seja interpretado como HTML)
function fillTable(id, rows) {
  const tbody = $(id);
  tbody.replaceChildren();
  for (const [label, value] of rows) {
    const tr = document.createElement('tr');
    const th = document.createElement('th');
    const td = document.createElement('td');
    th.textContent = label;
    td.textContent = value;
    tr.append(th, td);
    tbody.append(tr);
  }
}

function render(data) {
  const s = data.summary;

  // Indicadores principais
  $('kpi-ram').textContent = s.ramPercent + '%';
  setBar('bar-ram', s.ramPercent);
  $('kpi-cpu').textContent = s.cpuPercent + '%';
  setBar('bar-cpu', s.cpuPercent);
  $('kpi-uptime').textContent = s.uptime;
  $('kpi-files').textContent = s.fileCount;
  $('kpi-ip').textContent = s.ip;
  $('kpi-status').textContent = s.status.label;

  // Selos no topo
  const statusBadge = $('status-badge');
  statusBadge.textContent = 'Status: ' + s.status.label;
  statusBadge.className = 'badge ' + s.status.level;

  const envBadge = $('env-badge');
  envBadge.textContent = (data.environment.isCloud ? 'Nuvem: ' : 'Ambiente: ') + data.environment.name;
  envBadge.className = 'badge ' + (data.environment.isCloud ? 'cloud' : 'local');

  // Sistema operacional
  const sys = data.system;
  fillTable('table-system', [
    ['Nome da máquina (hostname)', sys.hostname],
    ['Tipo do sistema', sys.type],
    ['Plataforma', sys.platform],
    ['Versão do kernel', sys.kernel],
    ['Arquitetura do processador', sys.arch],
    ['Endianness', sys.endianness],
    ['Versão do Node.js', sys.nodeVersion],
  ]);

  // Ambiente de execução
  const env = data.environment;
  fillTable('table-env', [
    ['Ambiente detectado', env.name],
    ['Tipo de execução', env.isCloud ? 'Nuvem (cloud)' : 'Local'],
    ['Porta utilizada', env.port],
    ['Modo de execução (NODE_ENV)', env.mode],
  ]);

  const vars = Object.entries(env.variables);
  fillTable('table-vars', vars.length > 0 ? vars : [['(nenhuma)', 'Nenhuma variável da plataforma encontrada']]);

  // Servidor e recursos
  const srv = data.server;
  fillTable('table-server', [
    ['Modelo da CPU', srv.cpuModel],
    ['Quantidade de CPUs', srv.cpuCount],
    ['Carga média (1 / 5 / 15 min)', srv.loadAverage],
    ['Memória total', srv.totalMemory],
    ['Memória livre', srv.freeMemory],
    ['Memória em uso', srv.usedMemory],
    ['Limite de memória do contêiner', srv.containerMemoryLimit],
    ['Limite de CPU do contêiner', srv.containerCpuLimit],
    ['PID do processo', srv.processId],
    ['Tempo de atividade do processo', srv.processUptime],
    ['Memória RSS do processo', srv.processRss],
    ['Heap usado pelo processo', srv.processHeapUsed],
  ]);

  $('collected').textContent = 'Última coleta: ' + new Date(data.collectedAt).toLocaleString('pt-BR');
}

async function load() {
  try {
    const response = await fetch('/api/info');
    if (!response.ok) throw new Error('Resposta inválida');
    render(await response.json());
    $('error').hidden = true;
  } catch (err) {
    $('error').hidden = false;
  }
}

load();
setInterval(load, 5000);
