// dashboard-so-app
// Evolução do cloud-so-app: dashboard de monitoramento do sistema operacional.
// Coleta métricas com o módulo "os" do Node.js, detecta se está rodando
// localmente ou em nuvem (Render, Railway) e expõe tudo em /api/info.

const express = require('express');
const os = require('os');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const PROJECT_DIR = __dirname;

// ---------------------------------------------------------------------------
// Funções auxiliares
// ---------------------------------------------------------------------------

const toGB = (bytes) => (bytes / 1024 ** 3).toFixed(2);
const toMB = (bytes) => (bytes / 1024 ** 2).toFixed(1);

// Converte segundos em "1d 2h 3min 4s".
function formatUptime(totalSeconds) {
  const d = Math.floor(totalSeconds / 86400);
  const h = Math.floor((totalSeconds % 86400) / 3600);
  const m = Math.floor((totalSeconds % 3600) / 60);
  const s = Math.floor(totalSeconds % 60);
  return `${d}d ${h}h ${m}min ${s}s`;
}

// ---------------------------------------------------------------------------
// Uso médio de CPU
// os.cpus() devolve tempos acumulados (idle, user, sys...) desde o boot.
// Para obter um percentual, comparamos duas leituras: quanto do tempo total
// entre elas a CPU ficou ociosa. Amostramos a cada 2 segundos.
// ---------------------------------------------------------------------------

function readCpuTimes() {
  let idle = 0;
  let total = 0;
  for (const cpu of os.cpus()) {
    for (const type in cpu.times) {
      total += cpu.times[type];
    }
    idle += cpu.times.idle;
  }
  return { idle, total };
}

let lastCpuTimes = readCpuTimes();
let cpuPercent = 0;

setInterval(() => {
  const now = readCpuTimes();
  const idleDiff = now.idle - lastCpuTimes.idle;
  const totalDiff = now.total - lastCpuTimes.total;
  lastCpuTimes = now;
  if (totalDiff > 0) {
    cpuPercent = Number((100 - (idleDiff / totalDiff) * 100).toFixed(1));
  }
}, 2000).unref();

// ---------------------------------------------------------------------------
// Quantidade de arquivos do projeto (ignora node_modules e .git)
// ---------------------------------------------------------------------------

function countFiles(dir) {
  let count = 0;
  let entries = [];
  try {
    entries = fs.readdirSync(dir, { withFileTypes: true });
  } catch (err) {
    return 0;
  }
  for (const entry of entries) {
    if (entry.name === 'node_modules' || entry.name === '.git') continue;
    if (entry.isDirectory()) {
      count += countFiles(path.join(dir, entry.name));
    } else if (entry.isFile()) {
      count += 1;
    }
  }
  return count;
}

// ---------------------------------------------------------------------------
// IP principal: primeiro endereço IPv4 que não seja de loopback
// ---------------------------------------------------------------------------

function getMainIp() {
  const interfaces = os.networkInterfaces();
  for (const name of Object.keys(interfaces)) {
    for (const addr of interfaces[name]) {
      const isIPv4 = addr.family === 'IPv4' || addr.family === 4;
      if (isIPv4 && !addr.internal) {
        return addr.address;
      }
    }
  }
  return '127.0.0.1';
}

// ---------------------------------------------------------------------------
// Limites de contêiner (cgroups). Em nuvem, o serviço roda em um contêiner
// com limites de memória e CPU que podem ser menores que os da máquina física.
// ---------------------------------------------------------------------------

function readFileSafe(file) {
  try {
    return fs.readFileSync(file, 'utf8').trim();
  } catch (err) {
    return null;
  }
}

function getContainerLimits() {
  // cgroup v2
  let mem = readFileSafe('/sys/fs/cgroup/memory.max');
  // cgroup v1
  if (mem === null) mem = readFileSafe('/sys/fs/cgroup/memory/memory.limit_in_bytes');

  let memoryLimit = 'indisponível';
  if (mem !== null) {
    const bytes = Number(mem);
    // valores gigantes (ou "max") significam "sem limite definido"
    memoryLimit = Number.isFinite(bytes) && bytes < 2 ** 50 ? `${toGB(bytes)} GB` : 'sem limite definido';
  }

  let cpuLimit = 'indisponível';
  const cpuMax = readFileSafe('/sys/fs/cgroup/cpu.max');
  if (cpuMax !== null) {
    const [quota, period] = cpuMax.split(' ');
    cpuLimit = quota === 'max' ? 'sem limite definido' : `${(Number(quota) / Number(period)).toFixed(2)} CPU(s)`;
  }

  return { memoryLimit, cpuLimit };
}

// ---------------------------------------------------------------------------
// Detecção do ambiente: local ou nuvem (Render, Railway)
// Cada plataforma injeta variáveis de ambiente próprias.
// ---------------------------------------------------------------------------

function detectEnvironment() {
  const env = process.env;
  const keys = Object.keys(env);

  if (env.RENDER || keys.some((k) => k.startsWith('RENDER_'))) {
    return { name: 'Render', isCloud: true };
  }
  if (keys.some((k) => k.startsWith('RAILWAY_'))) {
    return { name: 'Railway', isCloud: true };
  }
  return { name: 'Local', isCloud: false };
}

// Mostra apenas variáveis seguras: NODE_ENV, PORT e as da plataforma.
// Qualquer nome que lembre segredo (TOKEN, KEY, SECRET, PASSWORD) é ocultado.
function getSafeEnvVars() {
  const secretPattern = /(TOKEN|SECRET|KEY|PASSWORD|PASS)/i;
  const result = {};
  for (const key of Object.keys(process.env).sort()) {
    const isPlatformVar = key.startsWith('RENDER_') || key.startsWith('RAILWAY_');
    const isBasicVar = key === 'NODE_ENV' || key === 'PORT' || key === 'RENDER';
    if ((isPlatformVar || isBasicVar) && !secretPattern.test(key)) {
      result[key] = process.env[key];
    }
  }
  return result;
}

// ---------------------------------------------------------------------------
// Status geral da máquina, a partir do maior percentual entre RAM e CPU
// ---------------------------------------------------------------------------

function getStatus(ramPercent, cpuUsage) {
  const worst = Math.max(ramPercent, cpuUsage);
  if (worst >= 90) return { level: 'critical', label: 'Crítico' };
  if (worst >= 75) return { level: 'warning', label: 'Atenção' };
  return { level: 'ok', label: 'Saudável' };
}

// ---------------------------------------------------------------------------
// Coleta de todas as informações
// ---------------------------------------------------------------------------

function getInfo() {
  const totalMem = os.totalmem();
  const freeMem = os.freemem();
  const usedMem = totalMem - freeMem;
  const ramPercent = Number(((usedMem / totalMem) * 100).toFixed(1));
  const cpus = os.cpus();
  const procMem = process.memoryUsage();
  const environment = detectEnvironment();
  const limits = getContainerLimits();

  return {
    summary: {
      ramPercent,
      cpuPercent: cpuPercent,
      uptime: formatUptime(os.uptime()),
      fileCount: countFiles(PROJECT_DIR),
      ip: getMainIp(),
      status: getStatus(ramPercent, cpuPercent),
    },
    system: {
      hostname: os.hostname(),
      type: os.type(),
      platform: os.platform(),
      kernel: os.release(),
      arch: os.arch(),
      endianness: os.endianness() === 'LE' ? 'Little Endian (LE)' : 'Big Endian (BE)',
      nodeVersion: process.version,
    },
    environment: {
      name: environment.name,
      isCloud: environment.isCloud,
      port: String(PORT),
      mode: process.env.NODE_ENV || 'development',
      variables: getSafeEnvVars(),
    },
    server: {
      cpuModel: cpus.length > 0 ? cpus[0].model : 'indisponível',
      cpuCount: cpus.length,
      loadAverage: os.loadavg().map((n) => n.toFixed(2)).join(' / '),
      totalMemory: `${toGB(totalMem)} GB`,
      freeMemory: `${toGB(freeMem)} GB`,
      usedMemory: `${toGB(usedMem)} GB`,
      containerMemoryLimit: limits.memoryLimit,
      containerCpuLimit: limits.cpuLimit,
      processId: process.pid,
      processUptime: formatUptime(process.uptime()),
      processRss: `${toMB(procMem.rss)} MB`,
      processHeapUsed: `${toMB(procMem.heapUsed)} MB`,
    },
    collectedAt: new Date().toISOString(),
  };
}

// ---------------------------------------------------------------------------
// Rotas
// ---------------------------------------------------------------------------

// Arquivos estáticos do dashboard (HTML, CSS e JavaScript do navegador)
app.use(express.static(path.join(__dirname, 'public')));

// Dados em JSON, consumidos pelo dashboard a cada poucos segundos
app.get('/api/info', (req, res) => {
  res.json(getInfo());
});

// Rota simples para checar se o serviço está de pé
app.get('/health', (req, res) => {
  res.json({ status: 'ok' });
});

app.listen(PORT, () => {
  console.log(`dashboard-so-app rodando na porta ${PORT} (${detectEnvironment().name})`);
});
