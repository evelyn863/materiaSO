# dashboard-so-app

Dashboard de monitoramento de sistema operacional feito com Node.js e Express. É a evolução do `cloud-so-app` (atividade 6) para a atividade 7 de Sistemas Operacionais I.

## O que o dashboard mostra

- **Indicadores:** uso de RAM (%), uso médio da CPU (%), uptime formatado, quantidade de arquivos do projeto, IP principal e status geral (Saudável, Atenção ou Crítico).
- **Sistema operacional:** nome da máquina, tipo do sistema, plataforma, versão do kernel, arquitetura, endianness e versão do Node.js.
- **Ambiente de execução:** detecta se roda **localmente**, no **Render** ou no **Railway**, mostrando porta, modo de execução (`NODE_ENV`) e as variáveis de ambiente da plataforma.
- **Servidor e recursos:** modelo e quantidade de CPUs, carga média, memória total/livre/em uso, limites de contêiner (cgroups) e dados do processo (PID, RSS, heap).

## Como executar localmente

```bash
npm install
npm start
```

Abra http://localhost:3000. Os dados atualizam sozinhos a cada 5 segundos. A rota `/api/info` devolve tudo em JSON e `/health` indica se o serviço está de pé.

## Estrutura

```
dashboard-so-app/
├── server.js        # servidor Express e coleta de métricas (módulo os)
├── public/
│   ├── index.html   # página do dashboard
│   ├── style.css    # estilo
│   └── app.js       # busca /api/info e atualiza a página
├── package.json
└── .gitignore
```

## Como o status geral é calculado

Usa o maior valor entre o percentual de RAM e o de CPU: abaixo de 75% é **Saudável**, de 75% a 89% é **Atenção** e a partir de 90% é **Crítico**.

## Como a CPU é calculada

`os.cpus()` devolve tempos acumulados desde o boot. A cada 2 segundos o servidor compara duas leituras e calcula quanto do intervalo as CPUs ficaram ocupadas (100% menos o tempo ocioso).

## Publicação em nuvem

- Build Command: `npm install`
- Start Command: `npm start`
- A porta vem da variável `PORT`, que Render e Railway definem automaticamente.

O passo a passo e a comparação entre as plataformas estão em `../Relatorio-Comparativo.md`.
