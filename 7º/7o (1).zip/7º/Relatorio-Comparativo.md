# Atividade 7 — Dashboard de SO e relatório comparativo (Render x Railway)

**Disciplina:** Sistemas Operacionais I
**Autora:** Evelyn Antunes (evelyn863)
**Projeto:** `dashboard-so-app` (evolução do `cloud-so-app`, atividade 6)

> **Como usar este documento:** as partes marcadas com **[PREENCHER]** dependem de resultados reais (valores que aparecem no dashboard, URLs, prints e suas impressões). Rode o projeto, publique nas duas plataformas e complete esses campos com o que você observar.

---

## 1. Objetivo

Evoluir a aplicação Node.js/Express da atividade anterior para um dashboard completo de monitoramento do sistema operacional, capaz de identificar se está rodando localmente ou em nuvem, e publicar a mesma aplicação em duas plataformas (Render e Railway) para comparar os ambientes e as ferramentas.

## 2. O que foi desenvolvido

Pasta `dashboard-so-app/`:

| Item | Descrição |
|---|---|
| Indicadores executivos | % de uso de RAM, uso médio da CPU, uptime formatado, quantidade de arquivos do projeto, IP principal e status geral (Saudável, Atenção, Crítico) |
| Sistema operacional | Nome da máquina, tipo do sistema, plataforma, versão do kernel, arquitetura, endianness e versão do Node.js |
| Detecção de ambiente | Identifica Local, Render ou Railway pelas variáveis de ambiente e mostra porta, modo de execução e variáveis da plataforma |
| Servidor e recursos | Modelo e número de CPUs, carga média, memória total, livre e em uso, limites de contêiner (cgroups) e dados do processo (PID, RSS, heap) |
| Rotas | `/` (dashboard), `/api/info` (JSON) e `/health` (verificação) |

### Como cada informação é obtida

- **RAM (%):** `(os.totalmem() - os.freemem()) / os.totalmem() * 100`.
- **CPU média (%):** `os.cpus()` devolve tempos acumulados desde o boot. A cada 2 segundos o servidor compara duas leituras e calcula `100 - (tempo ocioso / tempo total) * 100` no intervalo.
- **Uptime:** `os.uptime()` em segundos, formatado em dias, horas, minutos e segundos.
- **Arquivos do projeto:** percurso recursivo com `fs.readdirSync`, ignorando `node_modules` e `.git`.
- **IP principal:** primeiro IPv4 não interno em `os.networkInterfaces()`.
- **Kernel, arquitetura, endianness:** `os.release()`, `os.arch()` e `os.endianness()`.
- **Local x nuvem:** o Render define variáveis como `RENDER` e `RENDER_SERVICE_NAME`; o Railway define variáveis que começam com `RAILWAY_`. Se nenhuma existir, a aplicação considera o ambiente local. Variáveis com nomes que lembram segredos (TOKEN, KEY, SECRET, PASSWORD) nunca são exibidas.
- **Limites de contêiner:** leitura dos arquivos de cgroup (`/sys/fs/cgroup/memory.max` e `cpu.max`), quando existem.

## 3. Execução local

```bash
cd dashboard-so-app
npm install
npm start
```

Abrir http://localhost:3000.

Checklist de testes:

- [ ] O dashboard abre e os seis indicadores aparecem preenchidos
- [ ] Os valores de RAM e CPU mudam após alguns segundos
- [ ] O selo mostra "Ambiente: Local"
- [ ] `/api/info` devolve JSON válido e `/health` devolve `{"status":"ok"}`
- [ ] Ao abrir um programa pesado, o uso de CPU/RAM sobe e o status pode mudar para Atenção

**[PREENCHER]** print do dashboard local.

## 4. Deploy no Render

Resumo (detalhes na atividade 6):

1. Em https://render.com, **New + → Web Service** e conectar o repositório `materiaSO`.
2. **Root Directory:** `7º/dashboard-so-app` (se o caractere `º` der problema, use um repositório separado só com a pasta do projeto).
3. **Build Command:** `npm install` e **Start Command:** `npm start`.
4. Criar o serviço e aguardar o deploy. A URL pública sai no formato `https://nome.onrender.com`.

**[PREENCHER]** URL do Render: ________________________ e print do dashboard.

## 5. Deploy no Railway

1. Entrar em https://railway.com e fazer login com o GitHub.
2. **New Project → Deploy from GitHub repo** e escolher `materiaSO` (autorizar o acesso ao repositório se pedir).
3. Abrir o serviço criado, ir em **Settings** e definir o **Root Directory** como `7º/dashboard-so-app`. (Alternativa, se o `º` der problema: repositório separado só com a pasta.)
4. O Railway detecta que é um projeto Node.js e usa `npm install` e `npm start`. Confirme em Settings se os comandos aparecem como esperado.
5. Em **Settings → Networking**, clicar em **Generate Domain** para criar a URL pública. Sem esse passo o serviço roda, mas não tem endereço de acesso.
6. Acompanhar o build em **Deployments → View logs** e abrir a URL gerada.

A porta é definida pela variável `PORT`, que o Railway injeta automaticamente; o código já usa `process.env.PORT`, então não precisa configurar nada.

**[PREENCHER]** URL do Railway: ________________________ e print do dashboard.

## 6. Dados coletados nos três ambientes

**[PREENCHER]** Abra o dashboard em cada ambiente e copie os valores:

| Informação | Local | Render | Railway |
|---|---|---|---|
| Ambiente detectado | | | |
| Nome da máquina (hostname) | | | |
| Tipo / plataforma | | | |
| Versão do kernel | | | |
| Arquitetura | | | |
| Endianness | | | |
| Quantidade de CPUs | | | |
| Memória total | | | |
| Memória livre | | | |
| Uso de RAM (%) | | | |
| Uso médio da CPU (%) | | | |
| Limite de memória do contêiner | | | |
| Limite de CPU do contêiner | | | |
| IP principal | | | |
| Uptime do sistema | | | |
| Versão do Node.js | | | |
| Porta | | | |
| Modo (NODE_ENV) | | | |
| Variáveis da plataforma | | | |

## 7. Comparação entre as ferramentas

Render e Railway são **PaaS** (*Platform as a Service*): o desenvolvedor entrega o código e a plataforma cuida de servidor, sistema operacional, rede e HTTPS. As diferenças abaixo são características gerais das plataformas. **Planos, preços e limites mudam com frequência**, então confirme nas páginas oficiais antes de citar números no trabalho.

| Aspecto | Render | Railway |
|---|---|---|
| Modelo de uso | Cria-se um serviço (*Web Service*) por formulário, escolhendo repositório, comandos e plano | Cria-se um projeto com serviços em um painel visual; a plataforma tenta detectar sozinha a linguagem e como construir |
| Deploy a partir do GitHub | Sim, automático a cada push na branch escolhida | Sim, automático a cada push na branch escolhida |
| Configuração de build | Build Command e Start Command preenchidos manualmente | Detecção automática, com ajuste em Settings quando necessário |
| URL pública | Gerada automaticamente (`.onrender.com`) ao criar o serviço | Precisa ser gerada em Settings → Networking (`.up.railway.app`) |
| Plano gratuito/cobrança | Possui instâncias gratuitas, que costumam dormir após um período sem acessos, e planos pagos com instâncias de tamanho fixo (**confirmar no site**) | Cobrança baseada no consumo de recursos, com crédito inicial para testes em vez de uma instância gratuita permanente (**confirmar no site**) |
| Comportamento em inatividade | No plano gratuito o serviço "dorme" e a primeira requisição demora | Depende do plano e da configuração; o serviço fica ativo enquanto houver crédito |
| Variáveis de ambiente | Definidas por serviço; variáveis próprias com prefixo `RENDER_` | Definidas por serviço/projeto; variáveis próprias com prefixo `RAILWAY_` |
| Infraestrutura extra | Bancos de dados, jobs agendados, discos persistentes | Bancos de dados e volumes criados no mesmo projeto, com visão em canvas |
| Observabilidade | Logs e métricas básicas no painel | Logs, métricas e histórico de deploys no painel |

**[PREENCHER]** adicione a sua experiência real: qual foi mais fácil de configurar, qual demorou mais no build, o que apareceu de diferente no dashboard e qualquer erro que tenha enfrentado.

## 8. Análise com conceitos de Sistemas Operacionais

- **Virtualização e contêineres:** em ambas as plataformas a aplicação roda em contêineres sobre servidores físicos compartilhados. O kernel é o do host (Linux), e `namespaces` e `cgroups` isolam e limitam os recursos. Por isso o hostname é um identificador gerado, e os limites de memória e CPU do contêiner (mostrados no dashboard) podem diferir do total visto em `os.totalmem()` e `os.cpus()`.
- **Sistema operacional hospedeiro:** localmente o SO pode ser Windows, macOS ou Linux; na nuvem é Linux. Isso aparece em `platform`, `kernel` e `type`.
- **Arquitetura e endianness:** o dashboard mostra `x64` ou `arm64` e a ordem dos bytes (Little Endian na maioria dos processadores atuais). Mostram que o software depende do hardware subjacente, mesmo abstraído pela nuvem.
- **Processos:** cada execução é um processo com PID próprio. Na nuvem, a plataforma inicia, monitora e reinicia o processo; localmente, quem controla é o usuário.
- **Gerenciamento de memória e CPU:** a RAM total pode ser compartilhada com outros contêineres do mesmo host, e o percentual de uso da aplicação deve ser lido junto com o limite do contêiner.
- **Serviços sob demanda e infraestrutura remota:** o acesso é por URL pública, os recursos são contratados por plano e o ambiente pode ser recriado a qualquer momento a cada deploy.

## 9. Conclusões

A evolução do `cloud-so-app` para um dashboard completo mostrou que as informações que uma aplicação enxerga sobre o sistema dependem diretamente do ambiente em que ela é executada. O mesmo código, sem nenhuma alteração, apresentou dados diferentes na máquina local, no Render e no Railway, e isso evidencia a relação entre aplicação, sistema operacional hospedeiro e hardware: o programa não acessa o hardware diretamente, mas consulta o kernel por meio do módulo `os` do Node.js, e o resultado reflete o ambiente que o kernel enxerga.

A comparação entre os ambientes permitiu observar, na prática, os conceitos de virtualização e infraestrutura remota. Na nuvem, a aplicação executa dentro de um contêiner sobre um servidor Linux compartilhado, com hostname gerado pela plataforma e limites de memória e CPU definidos por cgroups. Por isso, valores como memória total e quantidade de CPUs devem ser interpretados junto com os limites do contêiner, e não isoladamente. Já a detecção do ambiente pelas variáveis de ambiente (`RENDER_*` e `RAILWAY_*`) mostrou como as plataformas informam à aplicação onde ela está rodando, e como a porta (`PORT`) é definida pelo ambiente e não pelo código.

Os indicadores de uso de RAM e de CPU também reforçaram conceitos de gerenciamento de recursos. O percentual de CPU não é lido diretamente: é calculado a partir da diferença entre duas leituras dos tempos acumulados informados pelo sistema, o que ilustra a forma como o escalonador distribui o tempo de processamento entre os processos. O status geral (Saudável, Atenção ou Crítico) transforma esses números em uma interpretação rápida, como acontece em painéis de monitoramento profissionais. Informações como arquitetura e endianness lembram que o software continua dependente da arquitetura do processador, mesmo quando a infraestrutura é abstraída pela nuvem.

Quanto às plataformas, Render e Railway são serviços PaaS com o mesmo propósito: receber o código do GitHub, construir a aplicação e publicá-la em uma URL pública, sem que o desenvolvedor precise administrar servidor, sistema operacional ou rede. As diferenças estão no modelo de configuração (formulário de serviço no Render e painel de projeto com detecção automática no Railway), no processo de criação do domínio público, na política de planos e cobrança e no comportamento do serviço em períodos de inatividade. A escolha entre elas depende do contexto do projeto: orçamento, necessidade de manter o serviço sempre ativo, facilidade de configuração e recursos adicionais como bancos de dados e volumes.

De forma geral, a atividade permitiu relacionar conceitos vistos em aula (processos, memória, CPU, sistema operacional hospedeiro, virtualização e computação em nuvem) com um sistema real em funcionamento, e mostrou que publicar uma aplicação na nuvem facilita o deploy e a disponibilidade, ao custo de menos controle sobre o ambiente e de limites de recursos definidos pela plataforma.

## 10. Referências

- Módulo `os` do Node.js: https://nodejs.org/api/os.html
- Objeto `process` do Node.js: https://nodejs.org/api/process.html
- Express.js: https://expressjs.com
- Documentação do Render: https://render.com/docs
- Documentação do Railway: https://docs.railway.com
