const STORAGE_KEY = "organizafatec.tasks.v1";
const $ = (selector) => document.querySelector(selector);
const list = $("#task-list");
const dialog = $("#task-dialog");
let tasks = loadTasks();

function loadTasks() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
    return Array.isArray(saved) ? saved : [];
  } catch {
    return [];
  }
}
function persist() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
}
function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, char => ({
    "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;"
  })[char]);
}
function formatDate(date) {
  if (!date) return "Sem prazo";
  return new Date(`${date}T12:00:00`).toLocaleDateString("pt-BR");
}
function statusLabel(status) {
  return ({pending:"Pendente", progress:"Em andamento", done:"Concluída"})[status] || "Pendente";
}
function priorityLabel(priority) {
  return ({high:"Alta", medium:"Média", low:"Baixa"})[priority] || "Média";
}
function render() {
  const query = $("#search").value.trim().toLowerCase();
  const status = $("#status-filter").value;
  const priority = $("#priority-filter").value;
  const filtered = tasks.filter(task =>
    (status === "all" || task.status === status) &&
    (priority === "all" || task.priority === priority) &&
    `${task.title} ${task.subject}`.toLowerCase().includes(query)
  );
  $("#total-count").textContent = tasks.length;
  $("#pending-count").textContent = tasks.filter(t => t.status === "pending").length;
  $("#progress-count").textContent = tasks.filter(t => t.status === "progress").length;
  $("#done-count").textContent = tasks.filter(t => t.status === "done").length;
  $("#visible-count").textContent = `${filtered.length} ${filtered.length === 1 ? "item" : "itens"}`;
  $("#empty-state").classList.toggle("show", filtered.length === 0);
  list.innerHTML = filtered.map(task => `
    <article class="task-card" data-id="${escapeHTML(task.id)}">
      <div class="task-main">
        <h3>${escapeHTML(task.title)}</h3>
        <div class="task-meta">${escapeHTML(task.subject)} · Prazo: ${formatDate(task.date)}</div>
      </div>
      <div class="task-side">
        <span class="pill priority-${task.priority}">Prioridade ${priorityLabel(task.priority)}</span>
        <select class="status-select" data-action="status" aria-label="Status de ${escapeHTML(task.title)}">
          <option value="pending" ${task.status==="pending"?"selected":""}>Pendente</option>
          <option value="progress" ${task.status==="progress"?"selected":""}>Em andamento</option>
          <option value="done" ${task.status==="done"?"selected":""}>Concluída</option>
        </select>
        <button class="icon-btn" data-action="edit" aria-label="Editar tarefa">✎</button>
        <button class="icon-btn" data-action="delete" aria-label="Excluir tarefa">×</button>
      </div>
    </article>`).join("");
}
function openNewTask() {
  $("#task-form").reset();
  $("#task-id").value = "";
  $("#dialog-title").textContent = "Nova tarefa";
  $("#task-status").value = "pending";
  dialog.showModal();
}
function editTask(task) {
  $("#task-id").value = task.id;
  $("#task-title").value = task.title;
  $("#task-subject").value = task.subject;
  $("#task-date").value = task.date;
  $("#task-priority").value = task.priority;
  $("#task-status").value = task.status;
  $("#dialog-title").textContent = "Editar tarefa";
  dialog.showModal();
}
$("#open-form").addEventListener("click", openNewTask);
$("#close-form").addEventListener("click", () => dialog.close());
$("#cancel-form").addEventListener("click", () => dialog.close());
$("#task-form").addEventListener("submit", event => {
  event.preventDefault();
  const id = $("#task-id").value;
  const task = {
    id: id || (crypto.randomUUID ? crypto.randomUUID() : String(Date.now())),
    title: $("#task-title").value.trim(),
    subject: $("#task-subject").value.trim(),
    date: $("#task-date").value,
    priority: $("#task-priority").value,
    status: $("#task-status").value
  };
  if (!task.title || !task.subject || !task.date) return;
  if (id) tasks = tasks.map(item => item.id === id ? task : item);
  else tasks.push(task);
  persist(); render(); dialog.close();
});
list.addEventListener("click", event => {
  const button = event.target.closest("button[data-action]");
  if (!button) return;
  const card = button.closest("[data-id]");
  const task = tasks.find(item => item.id === card.dataset.id);
  if (!task) return;
  if (button.dataset.action === "edit") editTask(task);
  if (button.dataset.action === "delete" && confirm(`Excluir a tarefa "${task.title}"?`)) {
    tasks = tasks.filter(item => item.id !== task.id);
    persist(); render();
  }
});
list.addEventListener("change", event => {
  if (event.target.dataset.action !== "status") return;
  const id = event.target.closest("[data-id]").dataset.id;
  tasks = tasks.map(task => task.id === id ? {...task, status:event.target.value} : task);
  persist(); render();
});
["search","status-filter","priority-filter"].forEach(id => $(`#${id}`).addEventListener("input", render));
render();
